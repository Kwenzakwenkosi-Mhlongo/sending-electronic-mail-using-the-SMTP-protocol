/**
 * Full name: Mhlongo K  
 * Student number: 221200192  
 * Course code: CSC02B2  
 * Practical: SMTP Client with Attachment  
 *
 * This class implements a GUI SMTP client that supports attachments.
 */

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.net.*;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;

public class SmtpClientGUI extends JFrame {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTextField txtHost, txtPort, txtSender, txtRecipient;
    private JTextArea txtMessage, txtLog;
    private JButton btnSend, btnAttach;
    private File attachedFile = null;

    public SmtpClientGUI() {
        super("SMTP Client with Attachment");

        JPanel inputPanel = new JPanel(new GridLayout(5, 2, 5, 5));
        txtHost = new JTextField("mail.smtpbucket.com");
        txtPort = new JTextField("8025");
        txtSender = new JTextField("sender@csc2b.uj.ac.za");
        txtRecipient = new JTextField("recipient@csc2b.uj.ac.za");

        inputPanel.add(new JLabel("SMTP Host:")); inputPanel.add(txtHost);
        inputPanel.add(new JLabel("SMTP Port:")); inputPanel.add(txtPort);
        inputPanel.add(new JLabel("Sender Email:")); inputPanel.add(txtSender);
        inputPanel.add(new JLabel("Recipient Email:")); inputPanel.add(txtRecipient);
        inputPanel.add(new JLabel("Message:"));

        txtMessage = new JTextArea(8, 40);
        JScrollPane scrollMessage = new JScrollPane(txtMessage);

        btnSend = new JButton("Send");
        btnAttach = new JButton("Attach File");

        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.add(btnAttach);
        buttonPanel.add(btnSend);

        txtLog = new JTextArea(10, 50);
        txtLog.setEditable(false);
        JScrollPane scrollLog = new JScrollPane(txtLog);

        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.add(inputPanel, BorderLayout.NORTH);
        topPanel.add(scrollMessage, BorderLayout.CENTER);
        topPanel.add(buttonPanel, BorderLayout.SOUTH);

        getContentPane().setLayout(new BorderLayout(10, 10));
        getContentPane().add(topPanel, BorderLayout.NORTH);
        getContentPane().add(scrollLog, BorderLayout.CENTER);

        pack();
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        btnSend.addActionListener(e -> {
            btnSend.setEnabled(false);
            txtLog.setText("");
            new Thread(this::sendEmail).start();
        });

        btnAttach.addActionListener(e -> {
            JFileChooser chooser = new JFileChooser();
            if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
                attachedFile = chooser.getSelectedFile();
                log("Attached: " + attachedFile.getName());
            }
        });
    }

    private void sendEmail() {
        String host = txtHost.getText().trim();
        String portStr = txtPort.getText().trim();
        String sender = txtSender.getText().trim();
        String recipient = txtRecipient.getText().trim();
        String messageText = txtMessage.getText();

        try (Socket socket = new Socket(host, Integer.parseInt(portStr));
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {

            log("Connected to SMTP server: " + host + ":" + portStr);
            log("S: " + in.readLine());

            String localHost = InetAddress.getLocalHost().getHostName();
            sendCommand(out, in, "HELO " + localHost);
            sendCommand(out, in, "MAIL FROM:<" + sender + ">");
            sendCommand(out, in, "RCPT TO:<" + recipient + ">");
            sendCommand(out, in, "DATA");

            out.println("From: " + sender);
            out.println("To: " + recipient);
            out.println("Subject: Email with Attachment");
            out.println("Date: " + new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss Z").format(new Date()));
            out.println("MIME-Version: 1.0");

            if (attachedFile != null) {
                String boundary = "----=_Part_" + System.currentTimeMillis();
                out.println("Content-Type: multipart/mixed; boundary=\"" + boundary + "\"");
                out.println();
                out.println("--" + boundary);
                out.println("Content-Type: text/plain; charset=\"utf-8\"");
                out.println("Content-Transfer-Encoding: 7bit");
                out.println();
                out.println(messageText);
                out.println();

                // Attachment
                String fileName = attachedFile.getName();
                String mimeType = Files.probeContentType(attachedFile.toPath());
                byte[] fileData = Files.readAllBytes(attachedFile.toPath());
                String encoded = Base64.getEncoder().encodeToString(fileData);

                out.println("--" + boundary);
                out.println("Content-Type: " + mimeType + "; name=\"" + fileName + "\"");
                out.println("Content-Transfer-Encoding: base64");
                out.println("Content-Disposition: attachment; filename=\"" + fileName + "\"");
                out.println();

                for (int i = 0; i < encoded.length(); i += 76) {
                    out.println(encoded.substring(i, Math.min(i + 76, encoded.length())));
                }

                out.println("--" + boundary + "--");

            } else {
                out.println("Content-Type: text/plain; charset=\"utf-8\"");
                out.println();
                out.println(messageText);
            }

            out.println(".");
            out.flush();
            log("S: " + in.readLine());

            sendCommand(out, in, "QUIT");
            log("Email sent successfully.");

        } catch (Exception e) {
            showError("Error: " + e.getMessage());
        } finally {
            btnSend.setEnabled(true);
        }
    }

    private void sendCommand(PrintWriter out, BufferedReader in, String command) throws IOException {
        log("C: " + command);
        out.println(command);
        out.flush();
        String response = in.readLine();
        log("S: " + response);
        if (response == null || !(response.startsWith("2") || response.startsWith("3"))) {
            throw new IOException("SMTP error: " + response);
        }
    }

    private void log(String message) {
        SwingUtilities.invokeLater(() -> txtLog.append(message + "\n"));
    }

    private void showError(String message) {
        SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE));
    }

    /**
     * Launches the GUI.
     *
     * @param args command-line arguments
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new SmtpClientGUI().setVisible(true));
    }
}
