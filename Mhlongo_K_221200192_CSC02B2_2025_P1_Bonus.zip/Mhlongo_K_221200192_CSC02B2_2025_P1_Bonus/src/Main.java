/**
 * Full name: Mhlongo K  
 * Student number: 221200192  
 * Course code: CSC02B2  
 * Practical: SMTP Client  
 *
 * This is the main entry point for launching the SMTP client GUI application.
 */
public class Main {

    /**
     * Launches the SMTP client GUI.
     *
     * @param args Command-line arguments (not used).
     */
    public static void main(String[] args) {
        SmtpClientGUI.main(args);
    }
}
